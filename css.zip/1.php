<?php include('header.php'); ?>
				<div class="mainbar">
					<div class="mainbar_up">
						<p id="current_page"></p>
					</div>
					<div class="mainbar_down">
						<h4>Class 1</h4><hr>
					</div>
				</div>
<?php include('footer.php'); ?>