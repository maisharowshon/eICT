<?php include('header.php'); ?>
				<div class="mainbar">
					<div class="mainbar_up">
						<p id="current_page">
							Notifications
						</p>
					</div>
					<div class="mainbar_down">
						No notification
					</div>
				</div>
<?php include('footer.php'); ?>