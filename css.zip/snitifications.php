<?php include('header.php'); session_start();?>
				<div class="mainbar">
					<div class="mainbar_up">
						<p id="current_page">
							Notifications
						</p>
					</div>
					<div class="mainbar_down">
						No Notification
					</div>
 
</div>
<?php include('header.php'); ?>